package Alien::Foo2;

use strict;
use warnings;
use parent qw( Alien::Base );

1;
